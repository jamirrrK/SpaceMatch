<aside class="auth-story" aria-label="About SpaceMatch">
    <a class="auth-story-brand" href="{{ route('home') }}"><span class="brand-mark">S</span> SpaceMatch</a>
    <div class="auth-story-copy"><span class="eyebrow">YOUR NEXT CHAPTER</span><h2>A little more space.<br>A lot more possibility.</h2><p>From your first bedspace to a place of your own. Find a rental that fits the life you’re building.</p></div>
    <img src="{{ asset('assets/images/space-placeholder.svg') }}" alt="Illustration of a welcoming rental space" width="480" height="320">
    <div class="auth-story-foot"><x-icon name="pin" /> Made for finding your space in the Philippines.</div>
</aside>
